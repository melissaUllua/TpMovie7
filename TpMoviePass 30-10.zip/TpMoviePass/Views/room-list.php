<?php 
/*listar funciones de cine*/

?>